"""Retail Sales Analytics - clean, analyze, and export summary tables."""
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "retail_sales.csv"
OUT = ROOT / "outputs"
OUT.mkdir(exist_ok=True)

df = pd.read_csv(DATA, parse_dates=["Order_Date"])

# Basic data quality checks
print("Shape:", df.shape)
print("Missing values:\n", df.isna().sum())
print("Duplicate order IDs:", df["Order_ID"].duplicated().sum())

# KPI summary
kpis = pd.DataFrame({
    "Metric": ["Total Revenue", "Total Profit", "Total Orders", "Units Sold", "Average Order Value"],
    "Value": [
        df["Revenue"].sum(),
        df["Profit"].sum(),
        df["Order_ID"].nunique(),
        df["Quantity"].sum(),
        df["Revenue"].sum() / df["Order_ID"].nunique()
    ]
})
kpis.to_csv(OUT / "kpi_summary.csv", index=False)

# Monthly performance
df["Year_Month"] = df["Order_Date"].dt.to_period("M").astype(str)
monthly = df.groupby("Year_Month", as_index=False).agg(
    Revenue=("Revenue", "sum"), Profit=("Profit", "sum"), Orders=("Order_ID", "nunique")
)
monthly.to_csv(OUT / "monthly_sales.csv", index=False)

# Product and regional performance
product = df.groupby(["Product", "Category"], as_index=False).agg(
    Revenue=("Revenue", "sum"), Profit=("Profit", "sum"), Units=("Quantity", "sum")
).sort_values("Revenue", ascending=False)
product.to_csv(OUT / "product_performance.csv", index=False)

region = df.groupby("Region", as_index=False).agg(
    Revenue=("Revenue", "sum"), Profit=("Profit", "sum"), Orders=("Order_ID", "nunique")
).sort_values("Revenue", ascending=False)
region.to_csv(OUT / "region_performance.csv", index=False)

print("\nKPI summary:\n", kpis.to_string(index=False))
print("\nTop products:\n", product.head(5).to_string(index=False))
print("\nSaved summary files in:", OUT)
