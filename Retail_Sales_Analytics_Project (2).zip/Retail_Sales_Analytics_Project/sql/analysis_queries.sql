-- Run these queries after importing data/retail_sales.csv
-- into a SQL table named retail_sales.

-- 1. Overall business KPIs
SELECT
    SUM(Revenue) AS total_revenue,
    SUM(Profit) AS total_profit,
    COUNT(DISTINCT Order_ID) AS total_orders,
    SUM(Quantity) AS units_sold,
    AVG(Revenue) AS average_order_value
FROM retail_sales;

-- 2. Monthly revenue and profit
SELECT
    YEAR(Order_Date) AS sales_year,
    MONTH(Order_Date) AS sales_month,
    SUM(Revenue) AS monthly_revenue,
    SUM(Profit) AS monthly_profit
FROM retail_sales
GROUP BY YEAR(Order_Date), MONTH(Order_Date)
ORDER BY sales_year, sales_month;

-- 3. Best-selling products
SELECT Product, SUM(Quantity) AS units_sold, SUM(Revenue) AS revenue
FROM retail_sales
GROUP BY Product
ORDER BY revenue DESC;

-- 4. Region-wise performance
SELECT Region, SUM(Revenue) AS revenue, SUM(Profit) AS profit
FROM retail_sales
GROUP BY Region
ORDER BY revenue DESC;

-- 5. Sales channel comparison
SELECT Sales_Channel, COUNT(DISTINCT Order_ID) AS orders,
       SUM(Revenue) AS revenue, SUM(Profit) AS profit
FROM retail_sales
GROUP BY Sales_Channel;
