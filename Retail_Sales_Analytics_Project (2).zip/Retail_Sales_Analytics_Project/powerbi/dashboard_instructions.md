# Power BI Dashboard Instructions

## 1. Load data
- Open Power BI Desktop.
- Select **Get Data → Text/CSV**.
- Choose `data/retail_sales.csv`, then select **Load**.

## 2. Create measures
Select **Modeling → New measure** and add each measure:

```DAX
Total Revenue = SUM(retail_sales[Revenue])

Total Profit = SUM(retail_sales[Profit])

Total Orders = DISTINCTCOUNT(retail_sales[Order_ID])

Units Sold = SUM(retail_sales[Quantity])

Average Order Value = DIVIDE([Total Revenue], [Total Orders])

Profit Margin = DIVIDE([Total Profit], [Total Revenue], 0)
```

If your table name differs from `retail_sales`, replace it in the formulas.

## 3. Recommended report layout
- Cards: Total Revenue, Total Profit, Total Orders, Units Sold
- Line chart: `Order_Date` on X-axis, Total Revenue on Y-axis
- Bar chart: `Product` on Y-axis, Total Revenue on X-axis
- Column chart: `Region` on X-axis, Total Revenue on Y-axis
- Donut chart: `Sales_Channel` as Legend, Total Revenue as Values
- Slicers: `Category`, `Region`, `Sales_Channel`, `Order_Date`

## 4. Design tips
- Use a clear title: **Retail Sales Performance Dashboard**
- Format Revenue and Profit as currency (INR).
- Sort product revenue from highest to lowest.
- Keep the report to one clean overview page.
- Test each slicer before taking a screenshot for your GitHub README.

## 5. Dashboard questions to answer
1. Which product has the highest revenue?
2. Which region contributes most to sales?
3. Is revenue increasing or decreasing over time?
4. Which channel contributes more revenue?
